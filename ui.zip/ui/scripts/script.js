
(function () {
    const Http = new XMLHttpRequest();
    const url = navigator.onLine ? 'http://www.json-generator.com/api/json/get/bUOqVOHEjm' : '../assets/data/data.json';
    Http.open("GET", url);
    Http.send();

    Http.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const response = JSON.parse(this.responseText);
            console.log(response);
            createdData(response.title, response.sub_title, response.description);
            createdGrid(response.slots);
        }
    }
})();

function createdData(title, subTitle, description) {
    document.getElementById('title').innerHTML = title;
    document.getElementById('sub-title').innerHTML = subTitle;
    viewDescription(description);
}

function createdGrid(slots) {
    const grid = document.getElementById('slot-grid');
    const tHead = document.createElement('thead');
    const hRow = tHead.insertRow();
    const hCell = hRow.insertCell();
    hCell.setAttribute('colspan', 4);
    hCell.innerHTML = '<div class="slot-grid-header">\
        <i class="fa fa-caret-left nav-day-prev"></i>\
        <div class="slot-day">'+ slots[0].day + '</div>\
        <i class="fa fa-caret-right nav-day-next active"></i>\
    </div>';
    grid.appendChild(tHead);
    const tBody = document.createElement('tbody');
    for (let key of slots[0].data) {
        var bRow = tBody.insertRow();
        const cCell = bRow.insertCell();
        cCell.setAttribute('rowspan', 3);
        cCell.innerHTML = '<div class="slot-session">\
            <i class="fa"></i>\
            <span>'+ Object.getOwnPropertyNames(key)[0]
            + '</span>\
        </div>';
        cCell.querySelector('i').classList.add(key === 'morning' ? 'fa-sun-o' : key === 'evening' ? 'fa-sun-o' : 'fa-moon-o');
        var count = 1;
        for (let i of key[Object.getOwnPropertyNames(key)[0]]) {
            const cCell = bRow.insertCell();
            cCell.innerHTML = '<div class="slot">' + i.slot + '</div>';
            cCell.querySelector('div').classList.add(i.status === 'available' ? 'slot-available' : i.status === 'not-available' ? 'slot-over' : 'slot');
            if (i.status === 'available') {
                slotAvailabeHover(cCell.querySelector('div'));
            }
            if (count % 3 == 0) {
                bRow = tBody.insertRow();
            }
            count = count + 1;
        }
    }
    grid.appendChild(tBody);

}

function slotAvailabeHover(elm) {
    elm.addEventListener('mouseenter', function () {
        var newEl = document.createElement('div');
        newEl.classList.add('tooltip');
        newEl.innerHTML = 'Slot is available';
        this.parentNode.insertBefore(newEl, this.nextSibling);
    });
    elm.addEventListener('mouseout', function () {
        this.nextSibling.remove();
    })
    elm.addEventListener('click', function () {
        this.classList.toggle('active');
    })
}

const navBar = document.getElementById('nav-bar');
navBar.addEventListener('click', function () {
    this.classList.toggle('active');
});

const navLinks = document.getElementsByClassName('nav-link');
for (var i = 0; i < navLinks.length; i++) {
    navLinks[i].addEventListener('click', function () {
        deactiveNavLinks();
        this.classList.add('active');
    });
};

function deactiveNavLinks() {
    for (var i = 0; i < navLinks.length; i++) {
        navLinks[i].classList.remove('active');
    };
};

var search = document.getElementById('search');
search.addEventListener('click', function () {
    this.parentElement.classList.toggle('active');
});

function viewDescription(desc) {
    var elm = document.getElementById('description');
    if (desc.length < 100) return;

    elm.innerHTML = desc.slice(0, 200) + '<a href="#" id="more" class="view-more"><span>... </span>See More</a>' +
      '<span style="display:none;">' + desc.slice(200, desc.length) + ' <a href="#" id="less" class="view-less">See Less</a></span>';
    elm.querySelector('#more').addEventListener('click', function(event){
        event.preventDefault();
        this.style.display = 'none';
        this.nextSibling.style.display = 'inline';
    })
    elm.querySelector('#less').addEventListener('click', function(event){
        event.preventDefault();
        this.parentElement.style.display = 'none';
        this.parentElement.parentElement.querySelector('#more').style.display = 'inline';
    })
}